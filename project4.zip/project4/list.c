#include <stdio.h>
#include <stdlib.h>
#include "list.h"
#include <assert.h>

typedef struct node{
	struct node *next;
	struct node *prev;
	void *data;
}NODE;

struct list{
	int count;
	NODE *head;
	int (*compare)();
};

LIST *createList(int (*compare)())
{
	LIST *lp = malloc(sizeof(LIST));
	assert(lp!=NULL);
	lp->count = 0;
	lp->compare = compare;
	lp->head=malloc(sizeof(NODE));
	assert(lp->head!=NULL);		//creating list
	lp->head->next=lp->head;
	lp->head->prev=lp->head; 
	return lp;
}
//big 0 - 0(1)

void destroyList(LIST *lp)
{
	NODE *pDel, *pNext;
	assert(lp!=NULL);
	pDel=lp->head;
	do{
		pNext=pDel->next;
		free(pDel);
		pDel=pNext;
	} while (pDel!=lp->head);
	free(lp);				//freeing node
}
//big 0 - 0(n)



int numItems(LIST *lp)
{
	assert(lp!=NULL);
	return lp->count;
}
//big 0 - 0(1)




void addFirst(LIST *lp, void *item)
{
	assert(lp!=NULL && item!=NULL);
	NODE* new=malloc(sizeof(NODE));

	new->data=item;
	new->next=lp->head->next;
						//adding new node
	lp->head->next->prev=new;
	lp->head->next=new;
	new->prev=lp->head;
	new->next->prev=new;

	lp->count++;
}
//big 0 - o(1)


void addLast(LIST* lp, void* item)
{
	assert(lp!=NULL && item!=NULL);
	NODE* new=malloc(sizeof(NODE));
	new->data=item;

	new->prev=lp->head->prev;
	new->next=lp->head;
	lp->head->prev->next=new;
	lp->head->prev=new;
						//adding last node
	lp->count++;
}
//big 0 - 0(1)


void* removeFirst(LIST* lp)
{
	assert(lp!=NULL);
	NODE *pDel= lp->head->next;
	void*data =pDel->data;

	lp->head->next=p->next;
	p->next->prev=lp->head;
					//removing first node
	free(p);
	lp->count--;
	return data;
}
//big 0 - 0(1)


void* removeLast(LIST* lp)
{
	assert(lp!=NULL);
	NODE *pDel =lp->head->prev;
	void*data=pDel->data;

	lp->head->prev=p->prev;
	p->prev->next=lp->head;
					
	free(p);			//freeing last node
	lp->count--;
	return data;
}
//big 0 - 0(1)



void *getFirst(LIST *lp)
{
	assert(lp!=NULL);
	return (lp->head->next->data);
}
//big 0 - 0(1)


void *getLast(LIST *lp)
{
	assert(lp!=NULL);
	return (lp->head->prev->data);
}
//big 0 -0(n)

void removeItem(LIST* lp, void* item)
{
	assert(lp!=NULL&&item!=NULL);
	NODE* pDel=lp->head->next;
	int i;
	for(i=0;i<lp->count;i++)
	{
		if((*lp->compare)(item, pDel->data) == 0)
		{
			pDel->next->prev=pDel->prev;
			pDel->prev->next=pDel->next;
			free(pDel);
		}
		pDel=pDel->next;
	}
	lp->count--;	

}
//big 0 - o(n)



void* findItem(LIST* lp, void* item)
{
	assert(lp!=NULL);
	NODE* pDel=p->head->next;
	int i;
	for(i=0; i<lp->count; i++)
	{
		if((*lp->compare)(item, pDel->data) == 0)
		{
			return (pDel->data);
		}
		pDel=pDel->next;
	}
	return NULL;
}
//big 0 - 0(n)



void *getItems(LIST *lp)
{
	assert(lp!=NULL);
	void **New=malloc(sizeof(void*)*lp->count);

	assert(New!=NULL);
	int i=0;
	NODE *pDel=lp->head->next;
	for(i=0; i<lp->count; i++)
	{
		New[i]=pDel->data;
		pDel=pDel->next;
	}
	return New;	
	
}
//big 0 - 0(n)

