#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "set.h"
#include "list.h"

struct set{
	int count;
	int length;
	LIST** lists;
	int (*compare)();
	unsigned (*hash)();
};


SET *createSet(int maxElts, int (*compare)(), unsigned (*hash)())

{
	
	SET* sp;
						//creating set		
	sp=malloc(sizeof(SET));
	assert(sp!=NULL);

	sp->length = maxElts;
	sp->compare=compare;
	sp->hash=hash;
	sp->count=0;
	
	sp->lists = malloc(sizeof(void *)*sp->length);

	int i;
	for(i = 0; i < sp->length; i++)
	{
		sp->lists[i] = createList(compare);
	}

	return sp;
}
//big 0- 0(n)


void destroySet(SET* sp)
{					//destroying set
	free(sp->lists);
	free(sp);
}
//big 0- 0(n)


int numElements(SET* sp)
{
	assert(sp!=NULL);
	return (sp->count);
}
//big 0- 0(1)


void addElement(SET* sp, void* elt)
{
	assert(sp != NULL && elt != NULL);
	unsigned div = (*sp->hash)(elt);
	int divv = (div)%(sp->length);


		addFirst(sp->lists[divv],elt);
		sp->count++;
}
//big 0- 0(1)

void removeElement(SET*sp, void*elt)
{
					//removing elemnets	
	assert(sp!=NULL);
	assert(sp!=NULL&&elt!=NULL);
	unsigned div = (*sp->hash)(elt);
	int divv = (div)%(sp->length);
	removeItem(sp->list[divv],elt);
	sp->count--;
}
//big 0- 0(1)

void *findElement(SET*sp, void*elt)
{	
	assert(sp!=NULL&&elt!=NULL);
	unsigned div =(*sp->hash)(elt);
	int divv =(div)%(sp->length);	
	
	return(findItem(sp->list[divv],elt));							
}

//big 0 - 0(n)

void *getElements(SET *sp)
{
	assert(sp != NULL);
	void **array;
	void **copy;
	int count = 0;
	int i, j;
	array = malloc(sizeof(void*)*sp->count);
	for(i = 0; i < sp->length; i++)
	{
		copy = getItems(sp->lists[i]);
		for(j = 0; j< numItems(sp->lists[i]); j++)
			{
			array[count] = copy[j];
			count++;
			}
	}
	return array;

}

//big 0 - 0(n)
